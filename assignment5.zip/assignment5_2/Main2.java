package assignment5_2;

class Furniture {
    String name;
    String style;
    String material;
    float price;

    public Furniture(String name, String style, String material, float price) {
        this.name = name;
        this.style = style;
        this.material = material;
        this.price = price;
    }
}

abstract class FurnitureFactory {
    abstract Chair createChair();
    abstract Table createTable();
    abstract Sofa createSofa();
}

class ModernWoodFactory extends FurnitureFactory {
    Chair createChair() {
        return new Chair("Modern Wood Chair", "Modern", "Wood", 100);
    }

    Table createTable() {
        return new Table("Modern Wood Table", "Modern", "Wood", 200);
    }

    Sofa createSofa() {
        return new Sofa("Modern Wood Sofa", "Modern", "Wood", 300);
    }
}

class TraditionalMetalFactory extends FurnitureFactory {
    Chair createChair() {
        return new Chair("Traditional Metal Chair", "Traditional", "Metal", 120);
    }

    Table createTable() {
        return new Table("Traditional Metal Table", "Traditional", "Metal", 220);
    }

    Sofa createSofa() {
        return new Sofa("Traditional Metal Sofa", "Traditional", "Metal", 320);
    }
}

class IndustrialGlassFactory extends FurnitureFactory {
    Chair createChair() {
        return new Chair("Industrial Glass Chair", "Industrial", "Glass", 150);
    }

    Table createTable() {
        return new Table("Industrial Glass Table", "Industrial", "Glass", 250);
    }

    Sofa createSofa() {
        return new Sofa("Industrial Glass Sofa", "Industrial", "Glass", 350);
    }
}

class Chair extends Furniture {
    public Chair(String name, String style, String material, float price) {
        super(name, style, material, price);
    }
}

class Table extends Furniture {
    public Table(String name, String style, String material, float price) {
        super(name, style, material, price);
    }
}

class Sofa extends Furniture {
    public Sofa(String name, String style, String material, float price) {
        super(name, style, material, price);
    }
}

class FurnitureCreator {
    FurnitureFactory factory;

    public void setFactory(FurnitureFactory factory) {
        this.factory = factory;
    }

    public Chair createChair() {
        return factory.createChair();
    }

    public Table createTable() {
        return factory.createTable();
    }

    public Sofa createSofa() {
        return factory.createSofa();
    }
}

public class Main2 {
    public static void main(String[] args) {
        FurnitureCreator creator = new FurnitureCreator();

        // Create and print furniture from different factories
        creator.setFactory(new ModernWoodFactory());
        Chair chair1 = creator.createChair();
        Table table1 = creator.createTable();
        Sofa sofa1 = creator.createSofa();
        System.out.println(chair1.name + ", " + table1.name + ", " + sofa1.name);

        creator.setFactory(new TraditionalMetalFactory());
        Chair chair2 = creator.createChair();
        Table table2 = creator.createTable();
        Sofa sofa2 = creator.createSofa();
        System.out.println(chair2.name + ", " + table2.name + ", " + sofa2.name);

        creator.setFactory(new IndustrialGlassFactory());
        Chair chair3 = creator.createChair();
        Table table3 = creator.createTable();
        Sofa sofa3 = creator.createSofa();
        System.out.println(chair3.name + ", " + table3.name + ", " + sofa3.name);
    }
}

