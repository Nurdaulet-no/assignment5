package assignment5_1;

class Data {
    String type;
    Object content;

    public Data(String type, Object content) {
        this.type = type;
        this.content = content;
    }
}

abstract class DataProcessor {
    abstract void process(Data data);
}

class TextDataProcessor extends DataProcessor {
    void process(Data data) {
        System.out.println("Processing text data: " + data.content);
        System.out.println("Storing text data in the database");
    }
}

class AudioDataProcessor extends DataProcessor {
    void process(Data data) {
        // Process audio data
        System.out.println("Processing audio data: " + data.content);
        // Simulated storage in the database
        System.out.println("Storing audio data in the database");
    }
}

class VideoDataProcessor extends DataProcessor {
    void process(Data data) {
        // Process video data
        System.out.println("Processing video data: " + data.content);
        // Simulated storage in the database
        System.out.println("Storing video data in the database");
    }
}

class DataProcessorCreator {
    DataProcessor processor;

    public void setProcessor(DataProcessor processor) {
        this.processor = processor;
    }

    public void processData(Data data) {
        if (processor == null) {
            throw new IllegalArgumentException("Processor not set");
        }
        processor.process(data);
    }
}

public class Main1 {
    public static void main(String[] args) {
        DataProcessorCreator creator = new DataProcessorCreator();

        Data textData = new Data("text", "Sample text data");
        creator.setProcessor(new TextDataProcessor());
        creator.processData(textData);

        Data audioData = new Data("audio", "Sample audio data");
        creator.setProcessor(new AudioDataProcessor());
        creator.processData(audioData);

        Data videoData = new Data("video", "Sample video data");
        creator.setProcessor(new VideoDataProcessor());
        creator.processData(videoData);
    }
}

