package assignment5_3;

class Character1 {
    String name;
    String characterClass;
    Weapon weapon;
    int health;
    int mana;

    public Character1(String name, String characterClass, Weapon weapon, int health, int mana) {
        this.name = name;
        this.characterClass = characterClass;
        this.weapon = weapon;
        this.health = health;
        this.mana = mana;
    }
}

class Weapon {
    String type;
    int damage;
    int speed;
    int range;

    public Weapon(String type, int damage, int speed, int range) {
        this.type = type;
        this.damage = damage;
        this.speed = speed;
        this.range = range;
    }
}

abstract class CharacterFactory1 {
    abstract Character1 createCharacter();
    abstract Weapon createWeapon();
}

class WarriorSwordFactory extends CharacterFactory1 {
    Character1 createCharacter() {
        return new Character1("Warrior", "Sword", createWeapon(), 100, 50);
    }

    Weapon createWeapon() {
        return new Weapon("Sword", 20, 10, 2);
    }
}

class MageStaffFactory extends CharacterFactory1 {
    Character1 createCharacter() {
        return new Character1("Mage", "Staff", createWeapon(), 80, 100);
    }

    Weapon createWeapon() {
        return new Weapon("Staff", 15, 15, 5);
    }
}

class ArcherBowFactory extends CharacterFactory1 {
    Character1 createCharacter() {
        return new Character1("Archer", "Bow", createWeapon(), 90, 70);
    }

    Weapon createWeapon() {
        return new Weapon("Bow", 18, 12, 8);
    }
}

class CharacterCreator1 {
    CharacterFactory1 factory;

    public void setFactory(CharacterFactory1 factory) {
        this.factory = factory;
    }

    public Character1 createCharacter() {
        if (factory == null) {
            throw new IllegalArgumentException("Factory not set");
        }
        return factory.createCharacter();
    }

    public Weapon createWeapon() {
        if (factory == null) {
            throw new IllegalArgumentException("Factory not set");
        }
        return factory.createWeapon();
    }
}

public class Main3 {
    public static void main(String[] args) {
        CharacterCreator1 creator = new CharacterCreator1();

        creator.setFactory(new WarriorSwordFactory());
        Character1 warrior = creator.createCharacter();
        Weapon warriorWeapon = creator.createWeapon();
        System.out.println("Name: " + warrior.name + ", Class: " + warrior.characterClass + ", Weapon: " + warriorWeapon.type);

        creator.setFactory(new MageStaffFactory());
        Character1 mage = creator.createCharacter();
        Weapon mageWeapon = creator.createWeapon();
        System.out.println("Name: " + mage.name + ", Class: " + mage.characterClass + ", Weapon: " + mageWeapon.type);

        creator.setFactory(new ArcherBowFactory());
        Character1 archer = creator.createCharacter();
        Weapon archerWeapon = creator.createWeapon();
        System.out.println("Name: " + archer.name + ", Class: " + archer.characterClass + ", Weapon: " + archerWeapon.type);
    }
}

