package assignment5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Character {
    String name;
    String appearance;
    List<String> abilities;
    List<String> equipment;
    Map<String, Integer> attributes;

    public Character(String name) {
        this.name = name;
        this.abilities = new ArrayList<>();
        this.equipment = new ArrayList<>();
        this.attributes = new HashMap<>();
    }

    @Override
    public String toString() {
        return "Name: " + name + "\n" +
                "Appearance: " + appearance + "\n" +
                "Abilities: " + abilities + "\n" +
                "Equipment: " + equipment + "\n" +
                "Attributes: " + attributes;
    }
}

abstract class CharacterFactory {
    abstract Character createCharacter(String name);
}

class WarriorFactory extends CharacterFactory {
    public Character createCharacter(String name) {
        Character character = new Character(name);
        character.appearance = "Warrior appearance";
        character.abilities.add("Slash");
        character.abilities.add("Block");
        character.equipment.add("Sword");
        character.equipment.add("Shield");
        character.attributes.put("Strength", 10);
        character.attributes.put("Defense", 8);
        return character;
    }
}

class MageFactory extends CharacterFactory {
    public Character createCharacter(String name) {
        Character character = new Character(name);
        character.appearance = "Mage appearance";
        character.abilities.add("Fireball");
        character.abilities.add("Teleport");
        character.equipment.add("Staff");
        character.equipment.add("Robe");
        character.attributes.put("Intelligence", 12);
        character.attributes.put("Mana", 100);
        return character;
    }
}

class ArcherFactory extends CharacterFactory {
    public Character createCharacter(String name) {
        Character character = new Character(name);
        character.appearance = "Archer appearance";
        character.abilities.add("Arrow Shot");
        character.abilities.add("Dodge");
        character.equipment.add("Bow");
        character.equipment.add("Leather Armor");
        character.attributes.put("Agility", 10);
        character.attributes.put("Accuracy", 9);
        return character;
    }
}

class CharacterCreator {
    CharacterFactory factory;

    public void setFactory(CharacterFactory factory) {
        this.factory = factory;
    }

    public Character createCharacter(String name) {
        if (factory == null) {
            throw new IllegalArgumentException("Factory not set");
        }
        return factory.createCharacter(name);
    }
}

public class Main {
    public static void main(String[] args) {
        CharacterCreator creator = new CharacterCreator();

        // Create a Warrior character
        creator.setFactory(new WarriorFactory());
        Character warrior = creator.createCharacter("Warrior Bob");

        // Create a Mage character
        creator.setFactory(new MageFactory());
        Character mage = creator.createCharacter("Mage Alice");

        // Create an Archer character
        creator.setFactory(new ArcherFactory());
        Character archer = creator.createCharacter("Archer Mike");

        // Print character details
        System.out.println(warrior);
        System.out.println(mage);
        System.out.println(archer);
    }
}

